# Copyright 2019 Toyota Research Institute. All rights reserved.
import os

TEST_DIR = os.path.dirname(os.path.realpath(__file__))
TEST_DATA_DIR = os.path.join(TEST_DIR, "data")
