# Copyright 2020 Toyota Research Institute. All rights reserved.
import unittest


class TestDGPCLI(unittest.TestCase):
    # TODO: add unittests for cli
    pass


if __name__ == "__main__":
    unittest.main()
