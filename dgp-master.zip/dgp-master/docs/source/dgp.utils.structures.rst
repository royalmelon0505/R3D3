dgp.utils.structures package
============================


dgp.utils.structures.bounding\_box\_2d module
---------------------------------------------

.. automodule:: dgp.utils.structures.bounding_box_2d
   :members:
   :undoc-members:
   :show-inheritance:

dgp.utils.structures.bounding\_box\_3d module
---------------------------------------------

.. automodule:: dgp.utils.structures.bounding_box_3d
   :members:
   :undoc-members:
   :show-inheritance:

dgp.utils.structures.instance\_mask module
------------------------------------------

.. automodule:: dgp.utils.structures.instance_mask
   :members:
   :undoc-members:
   :show-inheritance:

dgp.utils.structures.key\_point\_2d module
------------------------------------------

.. automodule:: dgp.utils.structures.key_point_2d
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: dgp.utils.structures
   :members:
   :undoc-members:
   :show-inheritance:
