dgp.annotations package
=======================


dgp.annotations.base\_annotation module
---------------------------------------

.. automodule:: dgp.annotations.base_annotation
   :members:
   :undoc-members:
   :show-inheritance:

dgp.annotations.bounding\_box\_2d\_annotation module
----------------------------------------------------

.. automodule:: dgp.annotations.bounding_box_2d_annotation
   :members:
   :undoc-members:
   :show-inheritance:

dgp.annotations.bounding\_box\_3d\_annotation module
----------------------------------------------------

.. automodule:: dgp.annotations.bounding_box_3d_annotation
   :members:
   :undoc-members:
   :show-inheritance:

dgp.annotations.depth\_annotation module
----------------------------------------

.. automodule:: dgp.annotations.depth_annotation
   :members:
   :undoc-members:
   :show-inheritance:

dgp.annotations.key\_point\_2d\_annotation module
-------------------------------------------------

.. automodule:: dgp.annotations.key_point_2d_annotation
   :members:
   :undoc-members:
   :show-inheritance:

dgp.annotations.ontology module
-------------------------------

.. automodule:: dgp.annotations.ontology
   :members:
   :undoc-members:
   :show-inheritance:

dgp.annotations.panoptic\_segmentation\_2d\_annotation module
-------------------------------------------------------------

.. automodule:: dgp.annotations.panoptic_segmentation_2d_annotation
   :members:
   :undoc-members:
   :show-inheritance:

dgp.annotations.semantic\_segmentation\_2d\_annotation module
-------------------------------------------------------------

.. automodule:: dgp.annotations.semantic_segmentation_2d_annotation
   :members:
   :undoc-members:
   :show-inheritance:

dgp.annotations.transform\_utils module
---------------------------------------

.. automodule:: dgp.annotations.transform_utils
   :members:
   :undoc-members:
   :show-inheritance:

dgp.annotations.transforms module
---------------------------------

.. automodule:: dgp.annotations.transforms
   :members:
   :undoc-members:
   :show-inheritance:

dgp.annotations.visibility\_filter\_transform module
----------------------------------------------------

.. automodule:: dgp.annotations.visibility_filter_transform
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: dgp.annotations
   :members:
   :undoc-members:
   :show-inheritance:
