dgp package
===========

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   dgp.annotations
   dgp.datasets
   dgp.scripts
   dgp.utils


dgp.cli module
--------------

.. automodule:: dgp.cli
   :members:
   :undoc-members:
   :show-inheritance:

dgp.constants module
--------------------

.. automodule:: dgp.constants
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: dgp
   :members:
   :undoc-members:
   :show-inheritance:
