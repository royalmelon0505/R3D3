dgp.datasets package
====================


dgp.datasets.base\_dataset module
---------------------------------

.. automodule:: dgp.datasets.base_dataset
   :members:
   :undoc-members:
   :show-inheritance:

dgp.datasets.frame\_dataset module
----------------------------------

.. automodule:: dgp.datasets.frame_dataset
   :members:
   :undoc-members:
   :show-inheritance:

dgp.datasets.pd\_dataset module
-------------------------------

.. automodule:: dgp.datasets.pd_dataset
   :members:
   :undoc-members:
   :show-inheritance:

dgp.datasets.synchronized\_dataset module
-----------------------------------------

.. automodule:: dgp.datasets.synchronized_dataset
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: dgp.datasets
   :members:
   :undoc-members:
   :show-inheritance:
