dgp.contribs.pd package
=======================


dgp.contribs.pd.metadata\_pb2 module
------------------------------------

.. automodule:: dgp.contribs.pd.metadata_pb2
   :members:
   :undoc-members:
   :show-inheritance:

dgp.contribs.pd.metadata\_pb2\_grpc module
------------------------------------------

.. automodule:: dgp.contribs.pd.metadata_pb2_grpc
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: dgp.contribs.pd
   :members:
   :undoc-members:
   :show-inheritance:
